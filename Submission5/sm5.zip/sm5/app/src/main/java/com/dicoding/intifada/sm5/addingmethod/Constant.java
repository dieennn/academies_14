package com.dicoding.intifada.sm5.addingmethod;



public class Constant {
    public static final String API_KEY = "6556eaa1b1a2430940d6ad5e6cf9e5d0";
    public static final String API_KEY_GITHUB = "token 9ec837aaa58c40af21caa7a4ab938b5a0c409628";
}
