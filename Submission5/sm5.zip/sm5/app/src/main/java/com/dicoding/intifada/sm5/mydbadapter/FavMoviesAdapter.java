package com.dicoding.intifada.sm5.mydbadapter;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.dicoding.intifada.sm5.R;
import com.dicoding.intifada.sm5.addingmethod.AllOtherMethod;
import com.dicoding.intifada.sm5.mydbentity.MoviesModel;
import com.google.gson.Gson;

import java.util.ArrayList;

import timber.log.Timber;


public class FavMoviesAdapter extends RecyclerView.Adapter<FavMoviesAdapter.MoviesmViewHolder> {
    public static final String TAG = FavMoviesAdapter.class.getSimpleName();
    private Activity mActivity;
    private ArrayList<MoviesModel> moviesModelList = new ArrayList<>();

    public FavMoviesAdapter(Activity mActivity) {
        this.mActivity = mActivity;
    }

    public void setListMoviesm(ArrayList<MoviesModel> listMoviesModel) {
        if (listMoviesModel.size() > 0) {
            this.moviesModelList.clear();
        }
        this.moviesModelList.addAll(listMoviesModel);
        notifyDataSetChanged();
    }

    public void addItem(MoviesModel moviesModel) {
        this.moviesModelList.add(moviesModel);
        notifyItemInserted(moviesModelList.size() - 1);
    }

    public void removeItem(int position) {
        this.moviesModelList.remove(position);
        notifyItemRemoved(position);
        notifyItemRangeChanged(position, moviesModelList.size());
    }

    //click custome
    private OnItemClickCallback onItemClickCallback;

    public void setOnItemClickCallback(OnItemClickCallback onItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback;
    }

    public interface OnItemClickCallback {
        void onItemClicked(MoviesModel moviesModel);
    }

    @NonNull
    @Override
    public FavMoviesAdapter.MoviesmViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list_favorite, parent, false);
        return new MoviesmViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final FavMoviesAdapter.MoviesmViewHolder holder, int position) {
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onItemClickCallback.onItemClicked(moviesModelList.get(holder.getAdapterPosition()));
            }
        });
        holder.bind(moviesModelList.get(position));
    }

    @Override
    public int getItemCount() {
        if (moviesModelList == null) {
            return 0;
        } else {
            return moviesModelList.size();
        }
    }

    class MoviesmViewHolder extends RecyclerView.ViewHolder {
        CardView cardViewImg, cardViewDesc, cardViewRating;
        TextView tvTitle, tvRelease, tvRating, tvDesc;
        ImageView imgvPoster;
        RecyclerView recyclerView;

        MoviesmViewHolder(@NonNull View itemView) {
            super(itemView);
            tvTitle = itemView.findViewById(R.id.tv_item_title);
            tvRelease = itemView.findViewById(R.id.tv_item_release);
            tvRating = itemView.findViewById(R.id.tv_item_rating);
            tvDesc = itemView.findViewById(R.id.tv_item_desc);
            imgvPoster = itemView.findViewById(R.id.img_item_photo);
            cardViewImg = itemView.findViewById(R.id.card_img);
            cardViewDesc = itemView.findViewById(R.id.card_view_desc);
            cardViewRating = itemView.findViewById(R.id.card_view_rating);
            recyclerView = itemView.findViewById(R.id.rv_tab_movies_room);
        }

        void bind(MoviesModel movieItems) {
            Timber.d("getFav : %s", new Gson().toJson(movieItems));
            String pathImg = "https://image.tmdb.org/t/p/w300_and_h450_bestv2";
            String title = movieItems.getTitle();
            String release = movieItems.getRelease_date();
            String voteValue = movieItems.getVote_average().toString();
            String overView = movieItems.getOverview();
            String imgUrl = movieItems.getPoster_path();

            String login = movieItems.getLogin();
            String avatar_url = movieItems.getAvatar_url();

            //AllOtherMethod allOtherMethod = new AllOtherMethod();
            //String myDate = allOtherMethod.changeFormatDate(release);
            tvTitle.setText(title);
            /*tvRating.setText("voteValue");
            tvDesc.setText("overView");
            tvRelease.setText("myDate");*/
            if (imgUrl != null) {
                Glide.with(mActivity)
                        .load(imgUrl)
                        .into(imgvPoster);
            }
        }
    }
}
